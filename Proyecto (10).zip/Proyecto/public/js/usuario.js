document.addEventListener('DOMContentLoaded', function () {
  const cerrarSesion = document.getElementById("btncerrarSesion");
  const modalEliminar = document.getElementById("modalEliminar");
  let eliminarTarget = null;

  cerrarSesion.addEventListener('click', function (e) {
    e.preventDefault();

    alert('Seguro que quieres cerrar sesión?')

    window.location.href = "/Login.html";
    history.replaceState(null, "", "/Login.html");


  });


});
function abrirModalEliminar() {
  modalEliminar.style.display = "block";
}


function cerrarModal() {
  modalEliminar.style.display = "none";
}

function abrirDetalles() {
  Detalles.style.display = "block";
}


function confirmarModal() {
  if (eliminarTarget) {

    eliminarTarget.parentNode.parentNode.remove();
    cerrarModal();
  }
}

// Función para abrir el modal de agregar producto


// Función para preparar la eliminación de un seguimiento
function Eliminar(elemento) {
  abrirModalEliminar();
  eliminarTarget = elemento; // Almacenar el botón que fue clickeado para su uso en confirmarModal
}

// Agregar escuchadores de eventos a los botones de borrar
document.querySelectorAll('.btnBorrar').forEach(btn => {
  btn.addEventListener('click', function () {
    Eliminar(this);
  });
});

// Opcional: Cerrar el modal si se hace clic fuera de él
window.onclick = function (event) {
  if (event.target == modalEliminar) {
    cerrarModal();
  }
};



document.addEventListener('DOMContentLoaded', function () {
  const usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');
  const tbody = document.querySelector('.table tbody');

  usuarios.forEach(seg => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${seg.usuario}</td>
      <td>${seg.correo}</td>
      <td>${seg.rol}</td>
      <td>${seg.fecha}</td>
      
      <td>
      <a class="btnEditar" href="./editarUsuario.html">Ver detalles</a>
      <button type="button" class="btnBorrar">Eliminar</button>
      </td>`
    tbody.appendChild(tr);







  });

});
