document.addEventListener('DOMContentLoaded', function (){
    var detalles = JSON.parse(localStorage.getItem('detalleProdutos'));
    
    if (detalles){
        document.getElementById('inputProducto1').value = detalles.producto;
        document.getElementById('inputDireccion1').value = detalles.direccion;
        document.getElementById('inputDestino1').value = detalles.destino;
        document.getElementById('inputLocalidad1').value = detalles.localidad;
        document.getElementById('inputEstado1').value = detalles.estado;
    }
    });
  
document.addEventListener('DOMContentLoaded', function () {
    const editButton = document.getElementById('editbtn');
    const canceButton = document.getElementById('cancelarbtn');
    const cerrarSesion = document.getElementById("btncerrarSesion");
    let isEditMode = false;

    editButton.addEventListener('click', function (e) {
        e.preventDefault();

        if (!isEditMode) {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute('readonly');
            });

            editButton.textContent = 'Guardar';
            isEditMode = true;

        } else {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute(true);
            });

            editButton.textContent = 'Editar';
            isEditMode = false;
            alert('Informacion guardada con exito');
        }



    });




    canceButton.addEventListener('click', function (e) {
        e.preventDefault();

        window.location.href = "/public/vistasAdmin/seguimientos.html";


    });

    cerrarSesion.addEventListener('click', function (e) {
        e.preventDefault();

        alert('Seguro que quieres cerrar sesión?')

        window.location.href = "/Login.html";
        history.replaceState(null, "", "/Login.html");


    });



});






