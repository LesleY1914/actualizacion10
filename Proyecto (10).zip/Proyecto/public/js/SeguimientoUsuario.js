
const Detalles = document.getElementById("verDetalles");
const modalEliminar = document.getElementById("modalEliminar");
const cerrarSesion = document.getElementById("btncerrarSesion");
let eliminarTarget = null; 


function abrirModalEliminar() {
  modalEliminar.style.display = "block";
}


function cerrarModal() {
  modalEliminar.style.display = "none";
}

function abrirDetalles() {
  Detalles.style.display = "block";
}


function confirmarModal() {
  if (eliminarTarget) {
    
    eliminarTarget.parentNode.parentNode.remove();
    cerrarModal();
  }
}





function Eliminar(elemento) {
  abrirModalEliminar();
  eliminarTarget = elemento; 
}


document.querySelectorAll('.btnBorrar').forEach(btn => {
  btn.addEventListener('click', function() {
    Eliminar(this);
  });
});


window.onclick = function(event) {
  if (event.target == modalEliminar) {
    cerrarModal();
  }
}

cerrarSesion.addEventListener('click', function(e){
  e.preventDefault();

  alert('Seguro que quieres cerrar sesión?')

  window.location.href ="/Login.html";
  history.replaceState(null,"", "/Login.html");

  
});

document.addEventListener('DOMContentLoaded', function () {
  const seguimientos = JSON.parse(localStorage.getItem('seguimientos') || '[]');
  const tbody = document.querySelector('.table tbody');

  seguimientos.forEach(seg => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${seg.producto}</td>
    <td>${seg.direccion}</td>
    <td>${seg.destino}</td>
    <td>${seg.localidad}</td>
    <td>${seg.estado}</td>
    <td>
      <a href="./verdetallesUsuario.html" class="btnEditar" style="padding: 5px;"> Ver detalles</a>
      <button type="button" class="btnBorrar" >Eliminar</button>
    </td>`
    tbody.appendChild(tr);







  });

});
