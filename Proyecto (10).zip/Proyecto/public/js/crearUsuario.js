document.getElementById('formUsuarios').addEventListener('submit', function(event){
  event.preventDefault();

  const usuario = document.querySelector('#inputUsuario').value;
  const correo = document.querySelector('#inputCorreo').value;
  const rol = document.querySelector('#inputRol').value;
  const fecha = document.querySelector('#inputFecha').value;
  

  const usuarios= JSON.parse(localStorage.getItem('usuarios') || '[]');
  usuarios.push({usuario, correo, rol, fecha});
  localStorage.setItem('usuarios', JSON.stringify(usuarios));

  alert('Usuario creado correctamente')
  window.location.href="./Usuarios.html";
  
});



document.addEventListener('DOMContentLoaded', function () {
    const cerrarSesion = document.getElementById("btncerrarSesion");


    cerrarSesion.addEventListener('click', function(e){
        e.preventDefault();
      
        alert('Seguro que quieres cerrar sesión?')
      
        window.location.href ="/Login.html";
        history.replaceState(null,"", "/Login.html");                                                       

        
      
        
      });

      



});



